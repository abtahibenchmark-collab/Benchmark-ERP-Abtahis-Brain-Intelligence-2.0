import ModulePage from '../../components/ModulePage';
export default function Page(){ return <ModulePage moduleKey="insights"/>; }
